//go:build d2

package service

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/hibiken/asynq"
	"log/slog"
	"tugas1-go/pertemuan-11-background-job/app/model"
	"tugas1-go/pertemuan-11-background-job/app/repository"
	"tugas1-go/pertemuan-11-background-job/helper"
)

// One task per quota event, but each recipient has a separate transaction.
// A retry skips committed recipients, so recipient 7 failing never re-sends 1-6.
func (w *NotificationWorker) handleQuotaEvent(ctx context.Context, job model.NotificationJob) (bool, error) {
	if job.EventType != model.EventCourseQuotaChanged {
		return false, nil
	}
	var event model.QuotaChangedEvent
	if err := json.Unmarshal(job.Payload, &event); err != nil {
		return true, fmt.Errorf("%w: payload kuota rusak: %v", asynq.SkipRetry, err)
	}
	if event.CourseID < 1 || event.Quota < 1 {
		return true, fmt.Errorf("%w: event kuota tidak valid", asynq.SkipRetry)
	}
	var permanentErrors []error
	for _, userID := range event.UserIDs {
		if userID < 1 {
			return true, fmt.Errorf("%w: penerima tidak valid", asynq.SkipRetry)
		}
		user, err := w.users.FindByID(ctx, userID)
		if errors.Is(err, repository.ErrNotFound) {
			permanentErrors = append(permanentErrors, fmt.Errorf("user %d dihapus", userID))
			continue
		}
		if err != nil {
			return true, err
		}
		subject := fmt.Sprintf("KRS: kuota %s %s berubah menjadi %d", event.CourseCode, event.CourseName, event.Quota)
		msg := model.Message{To: user.Email, Subject: subject, Body: fmt.Sprintf("Halo %s, %s.", user.Username, subject)}
		alreadySent := false
		err = w.tx.WithTxOnce(ctx, func(tx repository.DBTX) error {
			claimed, err := w.notifications.WithTx(tx).Claim(ctx, model.Notification{OutboxID: job.OutboxID, UserID: user.ID, Channel: "email", Subject: msg.Subject, Body: msg.Body})
			if err != nil {
				return err
			}
			if !claimed {
				alreadySent = true
				return nil
			}
			return w.mailer.Send(ctx, msg)
		})
		// Continue other recipients on permanent failure, then archive the event.
		if errors.Is(err, helper.ErrPermanentDelivery) {
			permanentErrors = append(permanentErrors, err)
			continue
		}
		if err != nil {
			return true, err
		}
		retry, _ := asynq.GetRetryCount(ctx)
		w.logger.Info("notification_processed", slog.Int64("outbox_id", job.OutboxID), slog.Int("user_id", userID), slog.String("event", job.EventType), slog.Int("retry", retry), slog.Bool("already_sent", alreadySent))
	}
	if len(permanentErrors) > 0 {
		return true, fmt.Errorf("%w: %v", asynq.SkipRetry, errors.Join(permanentErrors...))
	}
	return true, nil
}
