# D.2 — notifikasi perubahan kuota

IMPLEMENTED — NOT TESTED. Aktif hanya dengan build tag d2. Jangan aktifkan atau
menjalankan apa pun pada tahap implementasi ini.

Source varian berada di app/model/quota_event_d2.go,
app/service/course_quota_d2.go, app/service/quota_worker_d2.go, dan
app/repository/notification_claim_d2.go. Pasangan *_baseline.go memakai !d2.

UpdateQuota memakai WithTx agar UPDATE kuota/version dan INSERT outbox atomik.
Snapshot user_ids peserta diambil dalam transaction setelah UPDATE memegang lock
kelas. Kode/nama/kuota disalin ke event, sehingga retry tidak membaca nama/daftar
peserta yang telah berubah. Satu event menghasilkan satu task; tiap penerima
mempunyai transaction WithTxOnce dan claim sendiri.

Migration 009 mengganti UNIQUE(outbox_id) menjadi
UNIQUE(outbox_id,user_id,channel). Pasangan event/penerima/channel merupakan unit
pengiriman. Query claim KRS dan D.2 sama-sama menyesuaikan conflict key ketika
varian d2 aktif. Migration dan varian harus dipilih bersamaan. Setelah 009 diterapkan,
baseline harus dipakai pada database baseline terpisah dengan 008, bukan pada
database yang constraint-nya telah diganti.

Jika penerima ke-7 gagal sementara, transaction penerima itu rollback. Enam claim
yang sudah commit tetap ada. Retry melewati enam penerima tersebut dan mencoba
penerima ke-7 lagi. Permanent failure dikumpulkan sambil melayani penerima lain,
lalu task diarsipkan. Penerima yang dihapus juga dianggap permanent failure.
Gangguan setelah email terkirim sebelum commit tetap bisa menghasilkan email ganda;
ini batas dual write yang juga dijelaskan modul, bukan exactly-once.

Sembilan kandidat baseline tetap berlaku, termasuk tiga kandidat compiler dan
queue mismatch. Varian D.2 baru dapat dijalankan setelah perbaikan baseline
dibuktikan bersama. Tidak ada patch perbaikan puzzle tersembunyi di extension.

Tahap uji berikutnya: database/Redis khusus, minimal lima peserta, ubah kuota lewat
admin dengan version terkini, MAILER_FAIL_EVERY=3, kirim ulang lewat redeliver,
bandingkan per pasangan event/user/channel dengan baris mail.log. Uji penerima
ke-7 menggunakan setidaknya 8 peserta tambahan untuk memeriksa kasus batas itu.
Simpan kegagalan nyata, jumlah attempt, dan bukti penerima sukses tidak dikirimi
ulang. Semua keluaran dan screenshot masih kosong.
