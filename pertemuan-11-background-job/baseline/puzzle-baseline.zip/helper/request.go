package helper

import (
	"context"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"tugas1-go/pertemuan-11-background-job/app/model"
)

// RequestContext memberi batas waktu untuk operasi database.
func RequestContext(c *fiber.Ctx) (context.Context, context.CancelFunc) {
	return context.WithTimeout(c.UserContext(), 5*time.Second)
}

// ParamID membaca parameter :id dan memastikan nilainya valid.
func ParamID(c *fiber.Ctx) (int, bool) {
	id, err := strconv.Atoi(c.Params("id"))
	if err != nil || id < 1 {
		return 0, false
	}

	return id, true
}

var allowedSort = map[string]bool{
	"id":        true,
	"nim":       true,
	"name":      true,
	"grade":     true,
	"is_active": true,
}

// ParseListQuery membaca query parameter daftar mahasiswa.
func ParseAchievementListQuery(c *fiber.Ctx) model.ListQueryAchievement {
	q := model.ListQueryAchievement{
		Page: c.QueryInt("page", 1), Limit: c.QueryInt("limit", 10), Search: strings.TrimSpace(c.Query("search")), Sort: strings.ToLower(c.Query("sort", "id")), Order: strings.ToLower(c.Query("order", "asc")),
		Cursor: c.Query("cursor"),
	}
	if q.Page < 1 {
		q.Page = 1
	}
	if q.Limit < 1 {
		q.Limit = 10
	}
	if q.Limit > 100 {
		q.Limit = 100
	}
	allowed := map[string]bool{"id": true, "name": true, "student_id": true, "rank": true, "created_at": true}
	if !allowed[q.Sort] {
		q.Sort = "id"
	}
	if q.Order != "desc" {
		q.Order = "asc"
	}
	return q
}

func ParseUserListQuery(c *fiber.Ctx) model.UserListQuery {
	limit := c.QueryInt("limit", 10)
	if limit < 1 {
		limit = 10
	}
	if limit > 100 {
		limit = 100
	}
	return model.UserListQuery{Limit: limit, Cursor: c.Query("cursor")}
}

func ParseListQuery(c *fiber.Ctx) model.ListQuery {
	q := model.ListQuery{
		Page:   c.QueryInt("page", 1),
		Limit:  c.QueryInt("limit", 10),
		Search: strings.TrimSpace(c.Query("search")),
		Sort:   strings.ToLower(c.Query("sort", "id")),
		Order:  strings.ToLower(c.Query("order", "asc")),
		Cursor: c.Query("cursor"),
	}

	if q.Page < 1 {
		q.Page = 1
	}

	if q.Limit < 1 {
		q.Limit = 10
	}

	if q.Limit > 100 {
		q.Limit = 100
	}

	if !allowedSort[q.Sort] {
		q.Sort = "id"
	}

	if q.Order != "desc" {
		q.Order = "asc"
	}

	if raw := c.Query("is_active"); raw != "" {
		if value, err := strconv.ParseBool(raw); err == nil {
			q.IsActive = &value
		}
	}

	return q
}
