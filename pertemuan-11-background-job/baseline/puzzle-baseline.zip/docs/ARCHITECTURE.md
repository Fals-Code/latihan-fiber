# Kontrak dan penyesuaian arsitektur

Basis: source Pertemuan 10 yang memakai fondasi Pertemuan 7. Source dependensinya
disalin ke module baru; seluruh import menunjuk module baru, tanpa mengubah source
asal. PostgreSQL tetap menyimpan users, students, kelas dan KRS; MongoDB menyimpan
student_portfolios (implementasi aktual) serta course_reviews (panduan Modul 10).

Modul 9 juga edisi puzzle. Prasyaratnya diintegrasikan menurut komentar dan
spesifikasi akhir: DBTX pada callback TxManager, WithTx mengembalikan interface,
rollback selalu dijadwalkan, LockStudent memakai FOR UPDATE, UPDATE kursi memakai
enrolled_count < quota, DELETE memeriksa RowsAffected, Swap memakai repository tx,
dan UpdateQuota menaikkan version. Ini keputusan integrasi yang belum diuji,
bukan hasil perbaikan berbukti untuk tugas Modul 9.

users pada repo aktual memakai password_hash, bukan password. Seed 006 disesuaikan
ke kolom itu; nilai ! tetap tidak dapat digunakan sebagai hash bcrypt untuk login.
KRS memakai users.id, bukan students.id dari proyek UTS. Dataset kelas disalin dari
Modul 9 (IF101–IF399); urutan ID C.1 mengasumsikan database baru dan seed pertama.
Jangan memakai tabel courses/enrollments UTS karena kontraknya berbeda.

Nama helper aktual dipertahankan. helper/module_contract.go menjembatani NewError,
Validation, ValidateStruct dan error HTTP sesuai nama pada modul. Error repository
ErrNotFound/ErrDuplicate/ErrInvalidID dibagi dalam package yang sama, sehingga
tidak dideklarasikan dua kali setelah penggabungan portfolio dan review.

Migration warisan dipisahkan ke migrations/bootstrap untuk menghindari benturan
nomor 005 cursor pagination dengan 005_courses. Tidak ada migration otomatis.
Default database baru: pertemuan11_test dan pertemuan11_mongo; template Redis DB 11.
REDIS_DB adalah namespace praktikum, bukan mekanisme isolasi keamanan.

API hanya mengisi outbox untuk KRS dan membaca queue via inspector pada admin;
relay berada di proses worker. Worker Asynq memiliki context task sendiri sehingga
pembatalan context relay tidak langsung memutus pengiriman yang sedang berjalan.
Shutdown menutup HTTP, menunggu relay berhenti, lalu srv.Shutdown dengan batas
10 detik. Perilaku ini belum dijalankan maupun dibuktikan.

Sembilan pertentangan Modul 11 sengaja dipertahankan. Baseline bukan versi yang
diklaim siap berjalan. Extension d2 tidak memperbaiki kandidat-kandidat tersebut.
