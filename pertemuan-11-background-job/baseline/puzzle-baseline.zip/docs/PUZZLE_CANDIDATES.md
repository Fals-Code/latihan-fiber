# Kandidat puzzle Modul 11

Hanya hasil pembacaan statis, bukan berita acara hasil uji. Sembilan kandidat
tetap ada di source aktif. Jangan memperbaikinya sebelum bukti awal dicatat.

| ID | File/fungsi | Pertentangan dengan komentar/kontrak | Pembuktian nanti |
|---|---|---|---|
| P11-01 | helper/mailer.go / NewLogMailer | Nilai LogMailer dikembalikan sebagai Mailer, Send memakai pointer receiver | compiler |
| P11-02 | app/service/outbox_relay.go / publish | Struct job diberikan langsung sebagai payload NewTask | compiler |
| P11-03 | app/service/notification_worker.go / HandleSend | Parameter task berupa nilai, handler terdaftar mengharapkan pointer | compiler |
| P11-04 | app/service/course_service.go / Enroll | Insert outbox dipanggil lewat repository pool, bukan WithTx(tx) | C.1 pendaftaran ganda dan rollback |
| P11-05 | app/service/course_service.go / Drop | Event keluar dicatat sebagai enrollment.created | C.1 subjek dan event |
| P11-06 | app/service/outbox_relay.go / RelayOnce | ID dimasukkan ke daftar published sebelum enqueue diketahui berhasil | C.2 Redis mati/pulih |
| P11-07 | app/service/notification_worker.go / HandleSend | Claim tidak memakai repository WithTx(tx) meskipun berada di callback transaction | C.3 dan C.5 |
| P11-08 | app/service/notification_worker.go / HandleSend | SkipRetry dipasang pada %v; error pengiriman yang mendapat %w | C.4 jumlah attempt dan archived |
| P11-09 | config/queue.go / NewWorkerServer | Queues memakai nama task, berbeda dengan nama queue relay | C.1 jalur dasar dan monitoring |

Belum ada pesan compiler, gejala runtime, hitungan, atau bukti perbaikan.
Urutan pengujian berikutnya dimulai dengan baseline dan compiler, kemudian satu
perubahan tercatat setiap kali. Sebagian kandidat dapat menutupi kandidat lain.

Snapshot baseline berada di baseline/puzzle-baseline.zip dengan manifest SHA-256.
Ekstrak ke direktori terpisah ketika perlu membandingkan. Jangan ekstrak menimpa
pekerjaan yang telah diperbaiki. Untuk D.3, kembalikan satu kandidat yang lolos
compiler pada salinan kode yang sudah dibuktikan benar, bukan seluruh snapshot.
Hash hanya mengidentifikasi source; hash bukan bukti pengujian.
