# Rencana implementasi Pertemuan 11

Status: IMPLEMENTED — NOT TESTED.

Desain yang disetujui: Opsi A, satu folder pertemuan-11-background-job.
Module Go terpisah memakai import tugas1-go/pertemuan-11-background-job,
supaya dependency Asynq dan baseline yang sengaja tidak dapat dikompilasi
tidak mengubah proyek sebelumnya atau root go.mod/go.sum.

- [x] Baca PDF 9 (32 halaman), 10 (29 halaman), 11 (36 halaman).
- [x] Audit status Git dan basis source Pertemuan 10/Pertemuan 7.
- [x] Salin source aplikasi dan migration pendukung, tanpa evidence/tests/.env/logs.
- [x] Integrasikan kontrak akhir KRS Modul 9 dan seed kelas.
- [x] Tambahkan review Modul 10 dan pertahankan portfolio aktual.
- [x] Langkah 1: Asynq 0.26.0, konfigurasi Redis, template environment.
- [x] Langkah 2–5: migration 008, model, mailer, repository, WithTxOnce.
- [x] Langkah 6–8: event KRS, relay, worker, aturan pesan.
- [x] Langkah 9–10: role proses, shutdown, notifikasi dan monitoring.
- [x] Berkas Langkah 11: redeliver buatan sendiri, reset, monitoring.
- [x] D.2: varian opt-in dan migration 009 terpisah.
- [x] Simpan snapshot baseline dan sembilan kandidat untuk pembuktian berikutnya.
- [ ] Langkah 0 dan 11 runtime: pemeriksaan Redis dan menjalankan dua proses.
- [ ] Semua checkpoint compiler dan skenario C.1–C.8.
- [ ] Bukti sebelum/sesudah D.1, uji lima peserta D.2, pembanding D.3, screenshot.

Larangan sesi: tidak menjalankan test/build/vet, migration, service, HTTP aplikasi,
atau skenario pengujian. Tidak commit/push, tidak mengubah .env/evidence lama.
gofmt hanya dipakai untuk format source dan mengembalikan pemenggalan baris PDF.
Tidak ada klaim hasil compiler maupun runtime dari proses tersebut.
