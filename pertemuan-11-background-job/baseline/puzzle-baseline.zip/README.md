# Pertemuan 11 — Background Jobs

**IMPLEMENTED — NOT TESTED**

Opsi A: fondasi KRS Modul 9 diintegrasikan langsung ke folder ini. Basis source
Pertemuan 10 tetap membawa portfolio mahasiswa; review kelas Modul 10 ditambahkan
sesuai kontrak PDF. Proyek pertemuan sebelumnya, evidence lama, dan .env tidak diubah.

## Source utama

- app/model: KRS, review, notifikasi/outbox, portfolio, user/student.
- app/repository: DBTX, TxManager, CourseRepository, review MongoDB, outbox, claim.
- app/service: KRS, aturan pesan, relay outbox, worker, notification API, review.
- config/queue.go: Redis/Asynq, retry delay, error log, shutdown timeout.
- main.go dan worker.go: role api/worker/all serta lifecycle sumber daya.
- route: route lama, KRS/review, notifications/mine, admin/queue, portfolio.
- migrations: bootstrap, 005 kelas, 006 akun beban, 007 review permission, 008 outbox.
- tools/redeliver: alat buatan sendiri berdasarkan C.5, belum diverifikasi.
- extensions/d2: catatan varian kuota dan migration 009 opt-in.
- baseline: snapshot source awal dan manifest; docs: audit, kandidat, rencana uji.

## Status langkah modul

| Langkah | Status |
|---|---|
| 0 Redis/Memurai | Panduan dibaca; instalasi/ping/service ditunda |
| 1 Dependency/config | Asynq 0.26.0 dan dependency tercatat; template environment tersedia |
| 2–5 Skema/model/mailer/repository | Source tersedia, migration tidak dijalankan |
| 6 Event KRS | Enroll/Drop/Swap terintegrasi, kandidat puzzle dipertahankan |
| 7 Relay | Source tersedia, tidak dijalankan |
| 8 Worker | Source tersedia, tidak dijalankan |
| 9 Role/shutdown | Source tersedia, tidak dijalankan |
| 10 Endpoint | Route tersedia, tidak dikirimi request |
| 11 Dua proses | Berkas pendukung tersedia; pelaksanaan ditunda |
| D.2 | Varian build d2 dan migration 009 tersedia, tidak diaktifkan |

Baseline sengaja menyimpan sembilan kandidat kesalahan (termasuk tiga kandidat
compiler). Lihat docs/PUZZLE_CANDIDATES.md. Jangan menyatakan baseline dapat
dikompilasi atau menghasilkan keluaran penerimaan sebelum pembuktian berikutnya.
Tidak ada test/build/vet, server, worker, Redis, migration, request API, atau
screenshot yang dijalankan pada tahap ini. gofmt hanya merapikan source.

## Module dan konfigurasi lokal untuk tahap berikutnya

Folder ini mempunyai go.mod/go.sum sendiri, module
tugas1-go/pertemuan-11-background-job. Selalu gunakan direktori kerja folder ini;
root go.mod lama tidak mengelola nested module ini. Tidak perlu go.work.
Dependency disiapkan dengan go get github.com/hibiken/asynq@v0.26.0 tanpa build/test.

.env.example adalah template tanpa secret. .env aktual tidak dibuat atau diubah.
Isi konfigurasi nanti hanya setelah database khusus dipilih. Default contoh:
PostgreSQL pertemuan11_test, MongoDB pertemuan11_mongo, Redis logical DB 11,
port HTTP 3332. DB_MAX_CONNS=10 dan WORKER_CONCURRENCY=5 mengikuti batas modul.
JWT_SECRET harus diisi lokal minimal 32 karakter. godotenv membaca .env dari cwd;
environment proses mengalahkan file, jadi periksa override sebelum pengujian.

## Urutan migration untuk database BARU (belum dijalankan)

Tidak ada migrator otomatis. Jangan menerapkan pada database proyek lain.

1. bootstrap/001_create_students.sql
2. bootstrap/002_create_achievements.sql
3. bootstrap/003_auth.sql
4. bootstrap/003_rbac.sql
5. bootstrap/004_student_permissions.sql
6. bootstrap/005_users_cursor_pagination.sql
7. 005_courses.sql
8. 006_seed_loadtest.sql (akun praktikum tidak dapat login)
9. 007_review_permissions.sql
10. 008_outbox.sql

File bootstrap disalin dari basis aktual. Untuk database yang sudah ada, inventaris
schema dan migration dahulu; jangan mengulang urutan ini secara membabi buta.
Seed kelas mempertahankan urutan PDF agar C.1 punya pemetaan ID pada database baru.
reset11.sql hanya untuk akun mhsuji/salahalamat; ia belum pernah dijalankan.
tools/monitor.sql hanya berisi kueri pembacaan untuk tahap berikutnya.

Migration 009 di extensions/d2/migrations bukan bagian baseline. Aktifkan hanya
bersama varian d2, pada salinan database khusus setelah baseline diperbaiki dan
dibuktikan. Petunjuk D.2 ada di extensions/d2/README.md.

## Tahap berikutnya — belum dilakukan

Perintah compiler nanti dijalankan dari folder ini: go build ./... dan go vet ./....
Catat keluaran asli sebelum mengubah setiap kandidat. Jangan menjalankannya sekarang.
Setelah perbaikan compiler berbukti, proses dapat dipilih dengan -role=api atau
-role=worker. Seluruh C.1–C.8, D.2 fan-out, D.3 pembanding, dan screenshot menunggu
pelaksanaan bersama pengguna. Jumlah yang disebut modul adalah target, bukan hasil.

Redeliver memakai -outbox ID -copies 5. Alat membaca event dari PostgreSQL,
JSON-marshal NotificationJob, lalu enqueue dengan TaskID unik tiap salinan ke queue
notifications, MaxRetry 5, timeout 30 detik, retention 24 jam. Ia tidak menandai
published_at dan tidak memakai ID relay, sehingga lima salinan dapat ditambah satu
dari relay sesuai C.5. Pengiriman yang terputus di tengah dapat meninggalkan sebagian
salinan; jangan ulangi tanpa mencatat jumlah yang telah berhasil di-enqueue.

## Laporan

Dokumen Tugas_434241123: tab W10 dipertahankan. Tab w11 diturunkan dari struktur
sampul W10 melalui konektor (bukan operasi duplicate-tab native), lalu diisi kerangka
D.1–D.4 dan tabel D.1 sembilan baris. Hasil, bukti, jawaban analisis, serta screenshot
masih kosong. Tidak ada keluaran lama yang dianggap sebagai bukti Pertemuan 11.

Jangan commit/push .env, credentials, atau logs/. Belum ada commit/push tahap ini.
